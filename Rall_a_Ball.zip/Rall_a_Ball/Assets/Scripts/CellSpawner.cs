using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class CellSpawner : MonoBehaviour
{
    public GameObject cell;
    private Vector3 spawnVector;
    public float score;
    public Text scoretext;

    void ScoreUpdate()
    {
        scoretext.text = "Score: " + score.ToString();
    }

    void SpawnCell()
    {
        float randx = Random.Range(-10, 10);
        float randy = Random.Range(-10, 10);
        spawnVector = new Vector3(randx, 0.5f, randy);
        cell.transform.position = spawnVector;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            SpawnCell();
            other.GetComponent<PlayerController>().rb.transform.localScale += new Vector3(0.1f, 0.1f, 0.1f);
            other.GetComponent<PlayerController>().speed += 0.5f;
            score = score + 1;
            ScoreUpdate();
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
